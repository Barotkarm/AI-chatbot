// AI chat assistant: Express back end.
// The browser never sees the API key. It talks to this server, and this server talks to Claude.

const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const express = require("express");
const cookieParser = require("cookie-parser");
const Database = require("better-sqlite3");
const Anthropic = require("@anthropic-ai/sdk");

const PORT = process.env.PORT || 3000;
const MODEL = process.env.CLAUDE_MODEL || "claude-sonnet-5-5";
const MOCK = process.env.MOCK_AI === "1";           // fake AI for testing without a key
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "data", "chat.db");
const MAX_MESSAGE_CHARS = 4000;
const CONTEXT_MESSAGES = 30;                         // how many past messages the AI sees
const REQUEST_TIMEOUT_MS = 60_000;                   // give up on a slow answer after 60 s
const RATE_LIMIT = { windowMs: 60_000, max: 20 };    // 20 questions per minute per browser

const SYSTEM_PROMPT =
  "You are a helpful, friendly assistant in a chat window, possibly on a phone. " +
  "Answer clearly and accurately. Keep replies reasonably concise. " +
  "Use plain Markdown (short paragraphs, simple lists, code blocks) only when it helps.";

/* ---------- database ---------- */
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS messages (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id  TEXT NOT NULL,
    role       TEXT NOT NULL CHECK (role IN ('user','assistant')),
    content    TEXT NOT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_messages_client ON messages (client_id, id);
`);
const q = {
  insert: db.prepare("INSERT INTO messages (client_id, role, content, created_at) VALUES (?, ?, ?, ?)"),
  recent: db.prepare("SELECT id, role, content, created_at FROM messages WHERE client_id = ? ORDER BY id DESC LIMIT ?"),
  last: db.prepare("SELECT role, content FROM messages WHERE client_id = ? ORDER BY id DESC LIMIT 1"),
  clear: db.prepare("DELETE FROM messages WHERE client_id = ?"),
};
const history = (clientId, limit) => q.recent.all(clientId, limit).reverse();

/* ---------- Claude client ---------- */
const anthropic = !MOCK && process.env.ANTHROPIC_API_KEY
  ? new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY, maxRetries: 1 })
  : null;

/* Turn stored rows into a valid Claude conversation: starts with a user turn,
   and consecutive turns from the same side are merged. */
function toClaudeMessages(rows) {
  const out = [];
  for (const r of rows) {
    const last = out[out.length - 1];
    if (last && last.role === r.role) last.content += "\n\n" + r.content;
    else out.push({ role: r.role, content: r.content });
  }
  while (out.length && out[0].role !== "user") out.shift();
  return out;
}

/* Map any failure to a short message the user can act on. */
function friendlyError(err) {
  const status = err && err.status;
  if (err && err.code === "no_key") return { code: "no_key", message: "The server has no API key set. Ask the owner to set ANTHROPIC_API_KEY." };
  if (err && err.code === "timeout") return { code: "timeout", message: "The AI took too long to answer. Please try again." };
  if (status === 401 || status === 403) return { code: "auth", message: "The server's API key was rejected. Ask the owner to check it." };
  if (status === 429) return { code: "rate_limited", message: "The AI is busy or the usage limit was reached. Wait a minute and try again." };
  if (status >= 500 || status === 529) return { code: "ai_down", message: "The AI service is having trouble right now. Please try again shortly." };
  if (err && (err.name === "APIConnectionError" || err.name === "APIConnectionTimeoutError")) return { code: "network", message: "The server could not reach the AI. Please try again." };
  return { code: "unknown", message: "Something went wrong while getting the answer. Please try again." };
}

/* ---------- AI call (real or mock) ---------- */
async function streamAnswer({ messages, onText, signal }) {
  if (MOCK) {
    // Test helpers: "/fail" breaks, "/slow" takes a while, anything else gets a canned reply.
    const lastUser = messages[messages.length - 1].content;
    if (lastUser.startsWith("/fail")) { const e = new Error("mock failure"); e.status = 529; throw e; }
    const wait = (ms) => new Promise((res, rej) => {
      const t = setTimeout(res, ms);
      signal.addEventListener("abort", () => { clearTimeout(t); rej(Object.assign(new Error("aborted"), { code: "aborted" })); }, { once: true });
    });
    if (lastUser.startsWith("/slow")) await wait(20_000);
    const reply = `(mock answer) You asked: "${lastUser.slice(0, 200)}". I remember ${messages.length} message(s) in this chat.\n\n- This is a test reply\n- It is streamed word by word`;
    let full = "";
    for (const word of reply.split(/(?<=\s)/)) { await wait(25); full += word; onText(word); }
    return full;
  }
  if (!anthropic) throw Object.assign(new Error("no key"), { code: "no_key" });

  const stream = anthropic.messages.stream({ model: MODEL, max_tokens: 1500, system: SYSTEM_PROMPT, messages });
  signal.addEventListener("abort", () => stream.abort(), { once: true });
  let full = "";
  stream.on("text", (t) => { full += t; onText(t); });
  await stream.finalMessage();
  return full;
}

/* ---------- web server ---------- */
const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "20kb" }));
app.use(cookieParser());

// Each browser gets a random id in a cookie. That id owns its saved chat.
app.use("/api", (req, res, next) => {
  let id = req.cookies.cid;
  if (!/^[a-f0-9]{32}$/.test(id || "")) {
    id = crypto.randomBytes(16).toString("hex");
    res.cookie("cid", id, { httpOnly: true, sameSite: "lax", maxAge: 365 * 24 * 3600 * 1000 });
  }
  req.clientId = id;
  next();
});

// Very small in-memory rate limiter (per browser id).
const hits = new Map();
function rateLimit(req, res, next) {
  const now = Date.now();
  const list = (hits.get(req.clientId) || []).filter((t) => now - t < RATE_LIMIT.windowMs);
  if (list.length >= RATE_LIMIT.max) return res.status(429).json({ error: { code: "rate_limited", message: "You are sending messages too fast. Wait a minute and try again." } });
  list.push(now); hits.set(req.clientId, list);
  next();
}
setInterval(() => { const now = Date.now(); for (const [k, v] of hits) if (!v.some((t) => now - t < RATE_LIMIT.windowMs)) hits.delete(k); }, 60_000).unref();

app.get("/api/messages", (req, res) => {
  res.json({ messages: history(req.clientId, 200), ai: MOCK ? "mock" : anthropic ? "claude" : "no_key" });
});

app.delete("/api/messages", (req, res) => {
  q.clear.run(req.clientId);
  res.json({ ok: true });
});

app.post("/api/chat", rateLimit, async (req, res) => {
  const text = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  if (!text) return res.status(400).json({ error: { code: "empty", message: "Type a message first." } });
  if (text.length > MAX_MESSAGE_CHARS) return res.status(400).json({ error: { code: "too_long", message: `Please keep messages under ${MAX_MESSAGE_CHARS} characters.` } });

  // A retry after a failure sends the same text again: do not save the question twice.
  const last = q.last.get(req.clientId);
  if (!(last && last.role === "user" && last.content === text)) q.insert.run(req.clientId, "user", text, Date.now());

  // Stream the answer to the browser as Server-Sent Events.
  res.writeHead(200, { "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-cache, no-transform", Connection: "keep-alive", "X-Accel-Buffering": "no" });
  const send = (obj) => res.write(`data: ${JSON.stringify(obj)}\n\n`);

  const controller = new AbortController();
  const timer = setTimeout(() => { controller.timedOut = true; controller.abort(); }, REQUEST_TIMEOUT_MS);
  res.on("close", () => { if (!res.writableFinished) controller.abort(); });   // user pressed Stop or left

  try {
    const messages = toClaudeMessages(history(req.clientId, CONTEXT_MESSAGES));
    const answer = await streamAnswer({ messages, onText: (delta) => send({ delta }), signal: controller.signal });
    if (!answer.trim()) throw Object.assign(new Error("empty"), { status: 500 });
    q.insert.run(req.clientId, "assistant", answer, Date.now());
    send({ done: true });
  } catch (err) {
    if (controller.timedOut) err = Object.assign(err || new Error("timeout"), { code: "timeout" });
    if (controller.signal.aborted && !controller.timedOut) { /* user stopped: nothing to report */ }
    else { console.error("chat error:", err && (err.code || err.status || err.message)); send({ error: friendlyError(err) }); }
  } finally {
    clearTimeout(timer);
    res.end();
  }
});

app.use(express.static(path.join(__dirname, "public")));

app.listen(PORT, () => {
  const mode = MOCK ? "MOCK AI (no real answers)" : anthropic ? `Claude (${MODEL})` : "NO API KEY: set ANTHROPIC_API_KEY";
  console.log(`Chat assistant running at http://localhost:${PORT}  |  AI: ${mode}`);
});
