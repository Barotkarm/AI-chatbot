# Pocket Assistant

An AI chat assistant. Type any question, get an answer from Claude in a chat window.

- **Front end:** plain HTML, CSS and JavaScript (`public/index.html`)
- **Back end:** Node.js + Express (`server.js`)
- **Database:** SQLite file (`data/chat.db`), created automatically
- **AI:** Claude through the official `@anthropic-ai/sdk`, API key kept on the server

## Run it

1. Install Node.js 18 or newer.
2. Get an API key from https://console.anthropic.com (this is separate from a claude.ai chat plan).
3. In this folder:

```bash
npm install
export ANTHROPIC_API_KEY=your-key-here      # Windows PowerShell: $env:ANTHROPIC_API_KEY="your-key-here"
npm start
```

4. Open http://localhost:3000

To try the screen without a key, run `npm run dev`. It uses a fake AI that echoes your question.
In that mode, a message starting with `/fail` shows the error message and `/slow` shows the slow-answer note.

## How it works

1. The browser sends your question to `POST /api/chat`.
2. The server saves it, loads the last 30 messages, and asks Claude.
3. The answer streams back word by word (Server-Sent Events) and is saved when it finishes.
4. On refresh, the browser loads the chat from `GET /api/messages`.
5. A random id in a cookie tells the server which saved chat belongs to which browser.

| Endpoint | What it does |
|---|---|
| `POST /api/chat` | Send a question, stream the answer |
| `GET /api/messages` | Load the saved chat |
| `DELETE /api/messages` | Clear the chat |

## Slow or failed answers

- A "still working" note appears after 15 seconds, and the Send button becomes Stop.
- The server gives up after 60 seconds and says so.
- Rate limits, bad key, no key, network problems and AI outages each show a clear message with a Retry button.
- Retrying does not save the same question twice.

## Settings (environment variables)

| Name | Default | Meaning |
|---|---|---|
| `ANTHROPIC_API_KEY` | none | Your API key (required for real answers) |
| `CLAUDE_MODEL` | `claude-sonnet-5-5` | Which Claude model to use |
| `PORT` | `3000` | Port to listen on |
| `DB_PATH` | `data/chat.db` | Where the database file lives |
| `MOCK_AI` | off | Set to `1` for the fake AI |

## What I would add next

User accounts with login, several saved chats with titles, and a hosted database such as PostgreSQL.
